﻿namespace ReklaTool.Models.ViewModels;

public class PdfViewModel
{
    public string pdfBase64 { get; set; }
}
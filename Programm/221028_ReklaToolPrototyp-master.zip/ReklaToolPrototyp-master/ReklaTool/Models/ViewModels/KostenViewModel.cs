﻿namespace ReklaTool.Models.ViewModels;

public class KostenViewModel
{
    public string GesamtMitMwST { get; set; }
    public string GesamtOhneMwST { get; set; }
    public string Lackierung { get; set; }
    public string Arbeitslohn { get; set; }
    public string Ersatzteile { get; set; }
    public string Nebenkosten { get; set; }
    public string Lohnklasse1 { get; set; }
    public string Lohnklasse2 { get; set; }
    public string Lohnklasse3 { get; set; }
    public string Lohnklasse5 { get; set; }
    public string LackierungKlasse { get; set; }
}
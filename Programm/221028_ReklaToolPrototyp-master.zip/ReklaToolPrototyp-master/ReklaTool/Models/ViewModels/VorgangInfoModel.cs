﻿namespace ReklaTool.Models.ViewModels
{
    public class VorgangInfoModel
    {
        public string? Kalkulationssystem { get; set; }
        public string? Aktenzeichen { get; set; }
        public string? Kalkulationsdatum { get; set; }
    }
}

﻿namespace ReklaTool.Models.ViewModels;

public class XmlViewModel
{
    public string xmlBase64 { get; set; }
}
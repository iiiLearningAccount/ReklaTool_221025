﻿namespace ReklaTool.Models.ViewModels;

public class FahrzeugdatenViewModel
{
    public string HerstellerID { get; set; }
    public string HerstellerBezeichnung { get; set; }
    public string HaupttypID { get; set; }
    public string HaupttypBezeichnung { get; set; }
    public string UntertypID { get; set; }
    public string UntertypBezeichnung { get; set; }
}
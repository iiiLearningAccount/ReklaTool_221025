﻿namespace ReklaTool.Models.ViewModels;

public class AusstattungViewModel
{
    public string? Code { get; set; }
    public string? Bezeichnung { get; set; }
}
﻿namespace ReklaTool.Models.ViewModels;

public class RegelViewModel
{
    public string Name { get; set; }
    public string Text { get; set; }
    public string RegelID { get; set; }
}
﻿namespace TelerikAspNetCoreGridplusMenu.Models
{
    public class VorgangInfo
    {
        public string? Kalkulationssystem { get; set; }
        public string? Aktenzeichen { get; set; }
        public string? Kalkulationsdatum { get; set; }
    }
}

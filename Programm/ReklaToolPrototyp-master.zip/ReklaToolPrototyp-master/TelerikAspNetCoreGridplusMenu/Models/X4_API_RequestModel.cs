﻿using System.Text.Json;
using System.Xml.Serialization;
using TelerikAspNetCoreGridplusMenu.Controllers;
using TelerikAspNetCoreGridplusMenu.Utility;

namespace TelerikAspNetCoreGridplusMenu.Models
{
    [XmlRoot(ElementName = "Request", Namespace = "")]
    public class X4ApiRequestModel : XmlSerializerBase
    {
        [XmlElement(ElementName = "auftraggeber", IsNullable = true)]
        public string? Auftraggeber { get; set; }
        [XmlElement(ElementName = "kundennummer", IsNullable = true)]
        public string? Kundennummer { get; set; }
        [XmlElement(ElementName = "vorgangsnummer", IsNullable = true)]
        public string? Vorgangsnummer { get; set; }
        [XmlElement(ElementName = "dateiname", IsNullable = true)]
        public string? Dateiname { get; set; }
        [XmlElement(ElementName = "claimsGuard", IsNullable = true)]
        public ClaimsGuardTyp ClaimsGuard { get; set; }
        [XmlElement(ElementName = "schadennummer", IsNullable = true)]
        public string? Schadennummer { get; set; }
        public class ClaimsGuardTyp
        {
            [XmlElement(ElementName = "anwendbar")] public bool Anwendbar { get; set; } = false;
            [XmlElement(ElementName = "einzelpruefbericht")] public bool Einzelpruefbericht { get; set; } = false;
        }
        public X4ApiRequestModel() => ClaimsGuard = new ClaimsGuardTyp();
        public override int GetHashCode()
        {
            string str = JsonSerializer.Serialize(this);
            int hash1 = (5381 << 16) + 5381;
            int hash2 = hash1;

            for (int i = 0; i < str.Length; i += 2)
            {
                hash1 = ((hash1 << 5) + hash1) ^ str[i];
                if (i == str.Length - 1)
                    break;
                hash2 = ((hash2 << 5) + hash2) ^ str[i + 1];
            }

            return hash1 + (hash2 * 1566083941);
        }
    }
    public interface IRequestBuilder
    {
        RequestBuilder WithEinzelpruefbericht(bool includePruefbericht);
        RequestBuilder WithAnwendbar(bool isApplicable);
        X4ApiRequestModel Build(FilterRequest requestModel);
    }
    public class RequestBuilder : IRequestBuilder
    {
        private X4ApiRequestModel _request; 
        public RequestBuilder()
        {
            _request = new X4ApiRequestModel();
        }
        public X4ApiRequestModel Build(FilterRequest requestModel)
        {
            switch (requestModel.Aktenzeichen_Typ)
            {
                case "Vorgangsnummer":
                    _request.Vorgangsnummer = requestModel.Aktenzeichen;
                    break;
                case "Auftragsnummer":
                    _request.Auftraggeber = requestModel.Aktenzeichen;
                    break;
                case "Schadennummer":
                    _request.Schadennummer = requestModel.Aktenzeichen;
                    break;
                case "Dateiname":
                    _request.Dateiname = requestModel.Aktenzeichen;
                    break;
                default:
                    _request.Vorgangsnummer = requestModel.Aktenzeichen;
                    break;
            }
            return _request;
        }
        public RequestBuilder WithAnwendbar(bool isApplicable)
        {
            _request.ClaimsGuard.Anwendbar = isApplicable;
            return this;
        }
        public RequestBuilder WithEinzelpruefbericht(bool includePruefbericht)
        {
            _request.ClaimsGuard.Einzelpruefbericht = includePruefbericht;
            return this;
        }
    }
}

﻿using TelerikAspNetCoreGridplusMenu.Controllers;
using TelerikAspNetCoreGridplusMenu.Models;

namespace TelerikAspNetCoreGridplusMenu.Services
{
    public class UiEndpointService
    {
        private readonly Ix4_MsgService _msgService;
        public UiEndpointService(Ix4_MsgService msgService)
        {
            _msgService = msgService;
        }

        public List<VorgangInfo> GetVorgangInfos(FilterRequest model)
        {
            List<VorgangInfo> vorgangInfos = _msgService.GetVorgangInfos(model).Result;
            return vorgangInfos;
        }
        private PositionViewModel MapToPositionViewModel(Position position, string kategorie)
        {
            PositionViewModel positionViewModel = new PositionViewModel
            {
                Kategorie = kategorie,
                Code = position.Code,
                Bezeichnung = position.Bezeichnung,
                Leitnummer = position.Leitnummer,
                Repart = position.Repart,
                ReparaturText = position.ReparaturText,
                AW = position.AW,
                AWinStunden = position.AWinStunden,
                Betrag = position.Betrag,
                Bauart = position.Bauart,
                MaterialEigenschaft = position.MaterialEigenschaft,
                Lohnstufe = position.Lohnstufe,
                Materialeigenschaft = position.Materialeigenschaft,
                Teilenummer = position.Teilenummer,
                Platzhalter = position.Platzhalter,
                Stern = position.Stern,
                Lackbezeichnung = position.Lackbezeichnung,
                ArbeitspositionsNummer = position.ArbeitspositionsNummer,
                Lackart = position.Lackart
            };
            return positionViewModel;
        }

        public List<FahrzeugdatenViewModel> GetFahrzeugDaten(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            var fahrzeugdatenViewModels = new List<FahrzeugdatenViewModel>();
            Fahrzeugdaten fahrzeugdaten = vorgang.Fahrzeugdaten;
            FahrzeugdatenViewModel viewModel = new FahrzeugdatenViewModel
            {
                HerstellerID = fahrzeugdaten.HerstellerID,
                HerstellerBezeichnung = fahrzeugdaten.HerstellerBezeichnung,
                HaupttypID = fahrzeugdaten.HaupttypID,
                HaupttypBezeichnung = fahrzeugdaten.HaupttypBezeichnung,
                UntertypID = fahrzeugdaten.UntertypID,
                UntertypBezeichnung = fahrzeugdaten.UntertypBezeichnung
            };
            fahrzeugdatenViewModels.Add(viewModel);
            return fahrzeugdatenViewModels;
        }
        public List<KostenViewModel> GetKosten(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            var kostenViewModels = new List<KostenViewModel>();
            Reparaturkosten reparaturkosten = vorgang.Reparaturkosten;
            Lohnklassen lohnklassen = vorgang.Lohnklassen;
            KostenViewModel viewModel = new KostenViewModel()
            {
                GesamtMitMwST = reparaturkosten.GesamtMitMwST,
                GesamtOhneMwST = reparaturkosten.GesamtOhneMwST,
                Lackierung = reparaturkosten.Lackierung,
                Arbeitslohn = reparaturkosten.Arbeitslohn,
                Ersatzteile = reparaturkosten.Ersatzteile,
                Nebenkosten = reparaturkosten.Nebenkosten,
                Lohnklasse1 = lohnklassen.Lk1,
                Lohnklasse2 = lohnklassen.Lk2,
                Lohnklasse3 = lohnklassen.Lk3,
                Lohnklasse5 = lohnklassen.Lk5,
                LackierungKlasse = lohnklassen.Lackierung
            };
            kostenViewModels.Add(viewModel);
            return kostenViewModels;
        }
        public List<AusstattungViewModel> GetAusstattung(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            var ausstattungViewModels = new List<AusstattungViewModel>();
            var ausstattung = vorgang.Fahrzeugdaten.Ausstattung.Position;
            foreach (var position in ausstattung)
            {
                ausstattungViewModels.Add(new AusstattungViewModel{Code = position.Code, Bezeichnung = position.Bezeichnung});
            }
            return ausstattungViewModels;
        }
        public List<PositionViewModel> GetPositionen(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            List<IKategorie> Kategorien = new List<IKategorie>
            {
                vorgang.Instandsetzungen,
                vorgang.Ersatzteile,
                vorgang.Lackierung,
                vorgang.AnAbbau,
                vorgang.Hohlraum
            };
            List<PositionViewModel> positionViewModels = new List<PositionViewModel>();
            foreach (var Kat in Kategorien)
            {
                if (Kat != null)
                {
                    foreach (var pos in Kat.Position)
                    {
                        if (pos != null)
                        {
                            positionViewModels.Add(MapToPositionViewModel(pos, Kat.GetType().Name));
                        }
                    }
                }
            }
            return positionViewModels;
        }

        public List<RegelViewModel> GetRegeln(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            var regelViewModels = new List<RegelViewModel>();
            if (vorgang.Regeln != null)
            {
                var regeln = vorgang.Regeln.Regel;
                foreach (var regel in regeln)
                {
                    regelViewModels.Add(new RegelViewModel{ Name = regel.Name, Text = regel.Text, RegelID = regel.RegelID});
                }
            }
            return regelViewModels;
        }
        public byte[] GetPdf(FilterRequest model)
        {
            var vorgang = _msgService.GetVorgangByIdAsync(model).Result;
            PdfViewModel pdfViewModel = new PdfViewModel();
            byte[] byteData;
            if (vorgang.Einzelpruefbericht != null)
            {
                pdfViewModel = new PdfViewModel { pdfBase64 = vorgang.Einzelpruefbericht.Base64 };
                byteData = Convert.FromBase64String(pdfViewModel.pdfBase64);
            }
            else
            {
                string fileName = "PDFnochNichtVorhanden.pdf";
                string path = Path.Combine(Environment.CurrentDirectory, @"resources\", fileName);
                byteData = File.ReadAllBytes(path);
            }
            return byteData;
        }
    }

    public class KostenViewModel
    {
        public string GesamtMitMwST { get; set; }
        public string GesamtOhneMwST { get; set; }
        public string Lackierung { get; set; }
        public string Arbeitslohn { get; set; }
        public string Ersatzteile { get; set; }
        public string Nebenkosten { get; set; }
        public string Lohnklasse1 { get; set; }
        public string Lohnklasse2 { get; set; }
        public string Lohnklasse3 { get; set; }
        public string Lohnklasse5 { get; set; }
        public string LackierungKlasse { get; set; }
    }
    public class PdfViewModel
    {
        public string pdfBase64 { get; set; }
    }
    public class AusstattungViewModel
    {
        public string? Code { get; set; }
        public string? Bezeichnung { get; set; }
    }

    public class FahrzeugdatenViewModel
    {
        public string HerstellerID { get; set; }
        public string HerstellerBezeichnung { get; set; }
        public string HaupttypID { get; set; }
        public string HaupttypBezeichnung { get; set; }
        public string UntertypID { get; set; }
        public string UntertypBezeichnung { get; set; }
    }

    public class PositionViewModel 
    {
        public string Kategorie { get; set; }

        public string? Code { get; set; }
        public string? Bezeichnung { get; set; }
        public string? Leitnummer { get; set; }
        public string? Repart { get; set; }
        public string? ReparaturText { get; set; }
        public string? AW { get; set; }
        public string? AWinStunden { get; set; }
        public string? Betrag { get; set; }
        public string? Bauart { get; set; }
        public string? MaterialEigenschaft { get; set; }
        public string? Lohnstufe { get; set; }
        public string? Materialeigenschaft { get; set; }
        public string? Teilenummer { get; set; }
        public string? Platzhalter { get; set; }
        public string? Stern { get; set; }
        public string? Lackbezeichnung { get; set; }
        public string? ArbeitspositionsNummer { get; set; }
        public string? Lackart { get; set; }
    }

    public class RegelViewModel
    {
        public string Name { get; set; }
        public string Text { get; set; }
        public string RegelID { get; set; }
    }
}

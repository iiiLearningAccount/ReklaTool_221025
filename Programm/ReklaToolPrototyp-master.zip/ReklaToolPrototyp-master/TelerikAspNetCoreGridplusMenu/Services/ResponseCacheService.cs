﻿using System.Text.Json;
using TelerikAspNetCoreGridplusMenu.Models;

namespace TelerikAspNetCoreGridplusMenu.Services
{
    public interface ICacheService
    {
        //CacheElement GetElement(string name);

    }
    public class ResponseCacheService
    {
        private string cacheLocation = "D:\\01_Projects\\Visual Studio\\ASPnet\\ReklaToolPrototyp\\TelerikAspNetCoreGridplusMenu\\cache\\";
        public void SetElement(CacheElement element)
        {
            string contentHash = element.Anfrage.GetHashCode().ToString();
            File.WriteAllText(Path.Combine(cacheLocation, contentHash + ".json"), JsonSerializer.Serialize(element));
            File.WriteAllText(Path.Combine(cacheLocation, "testing.txt"), "Hello Test!!!");
        }

        public bool ElementExists(X4ApiRequestModel anfrage)
        {
            string contentHash = anfrage.GetHashCode().ToString();
            return File.Exists(Path.Combine(cacheLocation, contentHash + ".json")); ;
        }
        public Vorgaenge GetElement(X4ApiRequestModel anfrage)
        {
            string filename = anfrage.GetHashCode().ToString();
            string fileContent = File.ReadAllText(cacheLocation + filename + ".json");
            CacheElement result = JsonSerializer.Deserialize<CacheElement>(fileContent);
            return result.Vorgang;
        } 
    }
    public class CacheElement
    {
        public X4ApiRequestModel? Anfrage { get; set; }
        public Vorgaenge? Vorgang { get; set; }
    }
}

﻿using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;
using TelerikAspNetCoreGridplusMenu.Controllers;
using TelerikAspNetCoreGridplusMenu.Models;

namespace TelerikAspNetCoreGridplusMenu.Services
{
    public interface Ix4_MsgService
    {
        Task<Vorgaenge> GetVorgaengeAsync(FilterRequest model);
        Task<List<VorgangInfo>> GetVorgangInfos(FilterRequest model);
        Task<Vorgang> GetVorgangByIdAsync(FilterRequest model);
    }
    public class X4MsgService : Ix4_MsgService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;
        private readonly ResponseCacheService _cache;
        public X4MsgService(IConfiguration config, IHttpClientFactory clientFactory, ResponseCacheService cache)
        {
            _configuration = config;
            _clientFactory = clientFactory;
            _cache = cache;
        }
        public async Task<Vorgaenge> GetVorgaengeAsync(FilterRequest model)
        {
            IRequestBuilder requestBuilder = new RequestBuilder();
            X4ApiRequestModel anfrage = requestBuilder
                .WithAnwendbar(!model.IsSchnellsuche)
                .WithEinzelpruefbericht(!model.IsSchnellsuche)
                .Build(model);
            if (_cache.ElementExists(anfrage))
            {
                return _cache.GetElement(anfrage);
            }
            else
            {
                HttpClient client = _clientFactory.CreateClient();
                //client.Timeout = TimeSpan.FromSeconds(600);

                //declare type of request and URI plus request body
                var X4path = _configuration.GetValue<string>("ReklaConfig:X4Webaddress");
                var requestMsg = new HttpRequestMessage(HttpMethod.Post, X4path)
                {
                    Content = new StringContent(anfrage.ToXML())
                };

                //async send request to X4-server
                HttpResponseMessage response = await client.SendAsync(requestMsg);
                
                    //string from response
                var content = await response.Content.ReadAsStringAsync();
                
                //Deserialize Object from String //TODO:Error Handling
                var serializer = new XmlSerializer(typeof(Vorgaenge));
                using TextReader reader = new StringReader(content);
                Vorgaenge vorgaenge = (Vorgaenge)serializer.Deserialize(reader);

                //Write Object to Cachefile
                _cache.SetElement(new CacheElement{Anfrage = anfrage, Vorgang = vorgaenge});

                return vorgaenge;
            }
        }

        //TODO: Mock-Service erstellen
        public async Task<Vorgang> GetVorgangByIdAsync(FilterRequest model)
        {
            var vorgaengeAsync = await GetVorgaengeAsync(model);
            var result = vorgaengeAsync.Vorgang[model.VorgangIndex];
            return result;
        }
        public async Task<List<VorgangInfo>> GetVorgangInfos(FilterRequest model)
        {
            var vorgaengeAsync = await GetVorgaengeAsync(model);
            List<VorgangInfo> vorgangInfos = new List<VorgangInfo>();
            foreach (Vorgang vorgang in vorgaengeAsync.Vorgang)
            {
                vorgangInfos.Add(new VorgangInfo
                {
                    Aktenzeichen = vorgang.Kopfdaten.Aktenzeichen,
                    Kalkulationsdatum = vorgang.Kopfdaten.KalkulationsDatum,
                    Kalkulationssystem = vorgang.Kopfdaten.Kalksystem
                });
            }
            return vorgangInfos;
            
        }
    }
}
